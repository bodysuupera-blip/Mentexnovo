package com.arcade.labirintomortal;

import android.app.Activity;
import android.os.Bundle;
import android.view.*;
import android.graphics.*;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.widget.*;
import android.view.Gravity;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) { super.onCreate(b); setContentView(new GameView(this)); }

    static class GameView extends View {
        final Paint p = new Paint(3); final Random random = new Random();
        final int cols=13, rows=17; int[][] map=new int[rows][cols];
        float cell, ox, oy, px, py, enemyX, enemyY; int level=1, lives=5, score=0, coins=0;
        int dir=0, desired=0, tick=0, trapTick=0; boolean started=false, gameOver=false, won=false, shield=false;
        long last=0; String message=""; final int[][] dirs={{0,-1},{1,0},{0,1},{-1,0}};
        GameView(Context c){super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null); newLevel();}
        void newLevel(){
            for(int y=0;y<rows;y++) for(int x=0;x<cols;x++) map[y][x]=(x==0||y==0||x==cols-1||y==rows-1)?1:0;
            // Maze walls with guaranteed passages
            for(int y=2;y<rows-2;y+=3) for(int x=2;x<cols-2;x++) if(x%4!=0) map[y][x]=1;
            for(int x=3;x<cols-3;x+=4) for(int y=3;y<rows-3;y+=4) map[y][x]=1;
            // carve a connected central route
            for(int y=1;y<rows-1;y++) map[y][6]=0;
            for(int x=1;x<cols-1;x++) map[8][x]=0;
            // traps: 3 spikes, 2 laser gates, 1 fake tile
            for(int i=0;i<3+Math.min(level,4);i++){int x,y; do{x=1+random.nextInt(cols-2);y=1+random.nextInt(rows-2);}while(map[y][x]!=0||(x==1&&y==1)||(x==cols-2&&y==rows-2));map[y][x]=2;}
            for(int i=0;i<2;i++){int x,y; do{x=2+random.nextInt(cols-4);y=2+random.nextInt(rows-4);}while(map[y][x]!=0);map[y][x]=3;}
            px=1;py=1; enemyX=cols-2;enemyY=rows-2; dir=1;desired=1;trapTick=0;started=true;gameOver=false;won=false;shield=false;invalidate();
        }
        @Override protected void onDraw(Canvas c){super.onDraw(c); c.drawColor(Color.rgb(7,12,27)); float w=getWidth(),h=getHeight();
            p.setShader(new LinearGradient(0,0,w,h,0xff111b3b,0xff080d1b,Shader.TileMode.CLAMP)); c.drawRect(0,0,w,h,p);p.setShader(null);
            p.setColor(0xfff4f7ff);p.setTypeface(Typeface.create("sans-serif-black",1));p.setTextSize(w*.065f);c.drawText("LABIRINTO MORTAL",w*.07f,h*.055f,p);
            p.setTypeface(Typeface.create("sans-serif",1));p.setTextSize(w*.035f);p.setColor(0xff9db5d8);c.drawText("FASE "+level+"     ♥ "+lives+"     ★ "+score,w*.08f,h*.09f,p);
            cell=Math.min((w*.88f)/cols,(h*.61f)/rows);ox=(w-cols*cell)/2;oy=h*.15f;
            // board
            p.setColor(0xff121d3b);p.setStyle(Paint.Style.FILL);c.drawRoundRect(ox-7,oy-7,ox+cols*cell+7,oy+rows*cell+7,18,18,p);
            for(int y=0;y<rows;y++)for(int x=0;x<cols;x++){float l=ox+x*cell,t=oy+y*cell;
                if(map[y][x]==1){p.setColor(0xff263d78);c.drawRoundRect(l+2,t+2,l+cell-2,t+cell-2,7,7,p);p.setColor(0xff456bd0);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.5f);c.drawRoundRect(l+4,t+4,l+cell-4,t+cell-4,5,5,p);p.setStyle(Paint.Style.FILL);}
                else if(map[y][x]==2){p.setColor((tick/8)%2==0?0xffff4d6d:0xffa52c52);Path tr=new Path();tr.moveTo(l+cell*.5f,t+cell*.18f);tr.lineTo(l+cell*.83f,t+cell*.82f);tr.lineTo(l+cell*.17f,t+cell*.82f);tr.close();c.drawPath(tr,p);}
                else if(map[y][x]==3){p.setColor((tick/12)%2==0?0xffffb52e:0xff713d32);p.setStrokeWidth(4);c.drawLine(l+cell*.2f,t+cell*.5f,l+cell*.8f,t+cell*.5f,p);}
                else {p.setColor(0xff263653);c.drawCircle(l+cell/2,t+cell/2,cell*.055f,p);}
            }
            // exit
            p.setColor(0xff35e6b5);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);c.drawRoundRect(ox+(cols-2)*cell+5,oy+(rows-2)*cell+5,ox+(cols-1)*cell-5,oy+(rows-1)*cell-5,9,9,p);p.setStyle(Paint.Style.FILL);
            // enemy
            drawMonster(c,ox+(enemyX+.5f)*cell,oy+(enemyY+.5f)*cell,cell*.36f,true);
            drawMonster(c,ox+(px+.5f)*cell,oy+(py+.5f)*cell,cell*.38f,false);
            // controls
            float cy=h*.86f, r=w*.075f; drawButton(c,w*.5f,cy-r*1.15f,"▲");drawButton(c,w*.5f,cy+r*1.15f,"▼");drawButton(c,w*.5f-r*1.35f,cy,"◀");drawButton(c,w*.5f+r*1.35f,cy,"▶");
            p.setColor(0xff8ca4c9);p.setTextSize(w*.027f);p.setTypeface(Typeface.DEFAULT);c.drawText("TOQUE NAS SETAS PARA MOVER",w*.5f,h*.97f,p);p.setTextAlign(Paint.Align.LEFT);
            if(!started||gameOver||won){p.setColor(0xdd07101f);c.drawRoundRect(w*.08f,h*.32f,w*.92f,h*.66f,22,22,p);p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.create("sans-serif-black",1));p.setTextSize(w*.07f);c.drawText(won?"FASE CONCLUÍDA!":gameOver?"FIM DE JOGO":"ESCAPE DO LABIRINTO",w/2,h*.42f,p);p.setTextSize(w*.038f);p.setTypeface(Typeface.DEFAULT);c.drawText(won?"Você sobreviveu. Prepare-se para mais!":gameOver?"Suas vidas acabaram.":"Colete as estrelas, evite armadilhas e fuja!",w/2,h*.48f,p);p.setColor(0xff00d9c0);c.drawRoundRect(w*.28f,h*.53f,w*.72f,h*.60f,18,18,p);p.setColor(0xff061522);p.setTextSize(w*.043f);p.setTypeface(Typeface.create("sans-serif-black",1));c.drawText(won?"PRÓXIMA FASE":gameOver?"JOGAR NOVAMENTE":"COMEÇAR",w/2,h*.578f,p);p.setTextAlign(Paint.Align.LEFT);}
        }
        void drawButton(Canvas c,float x,float y,String s){p.setColor(0xff1d3158);c.drawCircle(x,y,getWidth()*.055f,p);p.setColor(0xff65e8ff);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);c.drawCircle(x,y,getWidth()*.055f,p);p.setStyle(Paint.Style.FILL);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(getWidth()*.06f);p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText(s,x,y+getWidth()*.02f,p);p.setTextAlign(Paint.Align.LEFT);}
        void drawMonster(Canvas c,float x,float y,float r,boolean enemy){p.setColor(enemy?0xffff4d78:0xff35e6ff);p.setShadowLayer(18,0,0,enemy?0xffff245e:0xff00cfff);c.drawCircle(x,y,r,p);p.clearShadowLayer();p.setColor(0xff071326);RectF mouth=new RectF(x-r*.55f,y-r*.05f,x+r*.55f,y+r*.65f);c.drawArc(mouth,0,180,true,p);p.setColor(Color.WHITE);c.drawCircle(x-r*.32f,y-r*.22f,r*.19f,p);c.drawCircle(x+r*.32f,y-r*.22f,r*.19f,p);p.setColor(0xff10172a);c.drawCircle(x-r*.28f,y-r*.2f,r*.09f,p);c.drawCircle(x+r*.36f,y-r*.2f,r*.09f,p);}
        boolean free(int x,int y){return x>0&&y>0&&x<cols-1&&y<rows-1&&map[y][x]!=1;}
        void step(){if(!started||gameOver||won)return;tick++;trapTick++;
            int nx=(int)px+dirs[desired][0],ny=(int)py+dirs[desired][1];if(free(nx,ny))dir=desired;
            nx=(int)px+dirs[dir][0];ny=(int)py+dirs[dir][1];if(free(nx,ny)){px=nx;py=ny;}
            int tx=(int)px,ty=(int)py;if(map[ty][tx]==2|| (map[ty][tx]==3&&(tick/12)%2==0)){if(shield){shield=false;}else{lives--;px=1;py=1;if(lives<=0)gameOver=true;}}
            else if(map[ty][tx]==0){score+=10; if(random.nextInt(5)==0)coins++;}
            // enemy moves toward player, but not through walls
            if(tick%2==0){int ex=(int)enemyX,ey=(int)enemyY;ArrayList<int[]> opts=new ArrayList<>();for(int d=0;d<4;d++){int ax=ex+dirs[d][0],ay=ey+dirs[d][1];if(free(ax,ay))opts.add(new int[]{ax,ay});}if(!opts.isEmpty()){opts.sort((a,b)->Integer.compare(Math.abs(a[0]-(int)px)+Math.abs(a[1]-(int)py),Math.abs(b[0]-(int)px)+Math.abs(b[1]-(int)py)));int[] a=opts.get(0);enemyX=a[0];enemyY=a[1];}}
            if(Math.abs(enemyX-px)<.1f&&Math.abs(enemyY-py)<.1f){lives--;px=1;py=1;if(lives<=0)gameOver=true;}
            if((int)px==cols-2&&(int)py==rows-2){won=true;level++;}
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_DOWN)return true;float x=e.getX(),y=e.getY(),w=getWidth(),h=getHeight();if(!started||gameOver||won){if(y>h*.50f&&y<h*.64f){if(gameOver){level=1;lives=5;score=0;coins=0;}newLevel();}invalidate();return true;}float cy=h*.86f,r=w*.075f;if(y<cy-r*.55f&&x>w*.35f&&x<w*.65f)desired=0;else if(y>cy+r*.55f&&x>w*.35f&&x<w*.65f)desired=2;else if(x<w*.5f)desired=3;else desired=1;return true;}
        @Override public void computeScroll(){super.computeScroll();long now=System.currentTimeMillis();if(now-last>230){last=now;step();invalidate();}postInvalidateDelayed(70);}
    }
}
