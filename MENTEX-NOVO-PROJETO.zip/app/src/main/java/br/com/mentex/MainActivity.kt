package br.com.mentex

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private data class Question(val text: String, val options: List<String>, val answer: Int, val hint: String)
    private val questions = listOf(
        Question("Qual planeta é conhecido como Planeta Vermelho?", listOf("Vênus", "Marte", "Júpiter", "Saturno"), 1, "É o quarto planeta a partir do Sol."),
        Question("Quanto é 7 × 8?", listOf("54", "56", "64", "48"), 1, "Pense em 7 grupos de 8."),
        Question("Qual é o maior oceano da Terra?", listOf("Atlântico", "Índico", "Pacífico", "Ártico"), 2, "Ele fica entre a Ásia/Oceania e as Américas."),
        Question("Qual destes é um mamífero?", listOf("Tubarão", "Golfinho", "Polvo", "Truta"), 1, "Respira por pulmões e amamenta os filhotes."),
        Question("Qual é a capital do Brasil?", listOf("Rio de Janeiro", "Salvador", "Brasília", "São Paulo"), 2, "Foi inaugurada em 1960.")
    )
    private var index = 0
    private var lives = 3
    private var coins = 0
    private var hintUsed = false
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var questionText: TextView
    private lateinit var feedback: TextView
    private val answerButtons = mutableListOf<Button>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 20, 46)
        window.navigationBarColor = Color.rgb(12, 20, 46)
        buildScreen()
        showQuestion()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun buildScreen() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(18), dp(20), dp(16))
            setBackgroundColor(Color.rgb(12, 20, 46))
        }
        val logo = TextView(this).apply {
            text = "M E N T E X"
            textSize = 26f; setTextColor(Color.rgb(85, 220, 255)); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; letterSpacing = 0.08f
        }
        root.addView(logo, LinearLayout.LayoutParams(-1, dp(48)))
        status = TextView(this).apply {
            textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(27, 39, 75)); setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        val statusParams = LinearLayout.LayoutParams(-1, dp(48)); statusParams.topMargin = dp(8)
        root.addView(status, statusParams)

        val progress = TextView(this).apply {
            text = "DESAFIO DE CONHECIMENTO"; textSize = 11f; letterSpacing = 0.12f
            setTextColor(Color.rgb(85, 220, 255)); gravity = Gravity.CENTER
        }
        val p = LinearLayout.LayoutParams(-1, dp(34)); p.topMargin = dp(10); root.addView(progress, p)

        questionText = TextView(this).apply {
            textSize = 22f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(Color.rgb(27, 39, 75))
        }
        val qParams = LinearLayout.LayoutParams(-1, 0, 1.0f); qParams.topMargin = dp(8); qParams.bottomMargin = dp(14)
        root.addView(questionText, qParams)

        repeat(4) { i ->
            val b = Button(this).apply {
                textSize = 15f; isAllCaps = false; setTextColor(Color.WHITE)
                backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(36, 57, 101))
                setOnClickListener { choose(i) }
            }
            val bp = LinearLayout.LayoutParams(-1, dp(52)); bp.bottomMargin = dp(8)
            root.addView(b, bp); answerButtons.add(b)
        }
        feedback = TextView(this).apply {
            textSize = 14f; setTextColor(Color.rgb(255, 215, 110)); gravity = Gravity.CENTER
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        root.addView(feedback, LinearLayout.LayoutParams(-1, dp(32)))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val hint = Button(this).apply {
            text = "💡 Dicas"; isAllCaps = false; setOnClickListener { showHint() }
        }
        val exit = Button(this).apply {
            text = "Sair"; isAllCaps = false; setOnClickListener {
                Toast.makeText(this@MainActivity, "Obrigado por jogar MENTEX!", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
        actions.addView(hint, LinearLayout.LayoutParams(0, dp(48), 1f))
        val gap = View(this); actions.addView(gap, LinearLayout.LayoutParams(dp(10), 1))
        actions.addView(exit, LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(actions)
        setContentView(root)
    }

    private fun showQuestion() {
        if (lives <= 0) {
            questionText.text = "Fim de jogo!\nVocê conquistou $coins moedas."
            answerButtons.forEach { it.isEnabled = false }
            feedback.text = "Reinicie o aplicativo para jogar novamente."
            return
        }
        val q = questions[index % questions.size]
        status.text = "❤️ $lives vidas     •     🪙 $coins moedas     •     ${index + 1}ª pergunta"
        questionText.text = q.text
        answerButtons.forEachIndexed { i, button ->
            button.text = "${('A'.code + i).toChar()}   ${q.options[i]}"
            button.isEnabled = true
            button.backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(36, 57, 101))
        }
        hintUsed = false
        feedback.text = "Escolha uma resposta"
    }

    private fun choose(choice: Int) {
        val q = questions[index % questions.size]
        if (choice == q.answer) {
            coins += 10
            feedback.text = "✓ Resposta correta! +10 moedas"
            answerButtons[choice].backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(25, 130, 100))
        } else {
            lives--
            feedback.text = "Resposta incorreta. A certa era ${q.options[q.answer]}."
            answerButtons[choice].backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(170, 55, 65))
        }
        answerButtons.forEach { it.isEnabled = false }
        status.text = "❤️ $lives vidas     •     🪙 $coins moedas"
        root.postDelayed({ index++; showQuestion() }, 1400)
    }

    private fun showHint() {
        val q = questions[index % questions.size]
        if (hintUsed) {
            feedback.text = "A dica desta pergunta já foi mostrada."
            return
        }
        hintUsed = true
        feedback.text = "Dica: ${q.hint}"
    }
}
