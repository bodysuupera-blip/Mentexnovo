# MENTEX — projeto Android inicial

Projeto Android nativo em Kotlin, preparado para compilar APK de debug pelo GitHub Actions.

## Como usar
1. Crie um repositório novo no GitHub, por exemplo `MENTEX-NOVO`.
2. Envie todos os arquivos e pastas deste ZIP para a raiz do repositório.
3. Abra **Actions** → **MENTEX - Compilar APK** → **Run workflow**.
4. Quando terminar, abra a execução e baixe o artefato **MENTEX-APK**.

## Observação importante
Este é um projeto novo funcional de base, com interface de perguntas, alternativas, vidas, moedas, dicas e saída. Como o arquivo original recebido era um APK e não o código-fonte do jogo, este projeto contém perguntas de demonstração e não garante reproduzir todas as perguntas, regras, recursos, imagens ou progressão do jogo original. O APK gerado pelo workflow é de debug, para teste.
